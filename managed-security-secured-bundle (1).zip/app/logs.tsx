import AsyncStorage from '@react-native-async-storage/async-storage';

const LOGS_KEY = '@secure_app_logs';

export interface SecurityLog {
  id: string;
  event: string;
  timestamp: string;
  details?: string;
}

export const logService = {
  async saveLog(event: string, details?: string): Promise<void> {
    try {
      const existingLogsJson = await AsyncStorage.getItem(LOGS_KEY);
      const existingLogs: SecurityLog[] = existingLogsJson ? JSON.parse(existingLogsJson) : [];
      
      const newLog: SecurityLog = {
        id: Math.random().toString(36).substring(2, 9),
        event,
        timestamp: new Date().toISOString(),
        details
      };
      
      const updatedLogs = [newLog, ...existingLogs].slice(0, 500);
      await AsyncStorage.setItem(LOGS_KEY, JSON.stringify(updatedLogs));
    } catch (error) {
      console.error("Lokal log yozishda xatolik:", error);
    }
  },

  async getLogs(): Promise<SecurityLog[]> {
    try {
      const logsJson = await AsyncStorage.getItem(LOGS_KEY);
      return logsJson ? JSON.parse(logsJson) : [];
    } catch (error) {
      console.error("Loglarni o'qishda xatolik:", error);
      return [];
    }
  }
};
